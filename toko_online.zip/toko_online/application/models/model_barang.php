<?php

class model_barang extends CI_Model
{
    public function tampil_data()
    {
        return $this->db->get('barang');
    }

    public function tambah_barang($data, $table)
    {
        $this->db->insert($table, $data);
    }

    // Catatan: Fungsi edit_barang ini harusnya bukan insert, tapi get_where
    public function edit_barang($where, $table)
    {
        return $this->db->get_where($table, $where);
    }

    public function update_barang($where, $data, $table)
    {
        $this->db->where($where);
        $this->db->update($table, $data);
    }

    public function hapus_data($where, $table)
    {
        $this->db->where($where);
        $this->db->delete($table);
    }

    public function find($id)
    {
        $result = $this->db->where('id_barang', $id)
                           ->limit(1)
                           ->get('barang');
        if ($result->num_rows() > 0) {
            return $result->row();
        } else {
            return array();
        }
    }

    public function get_kategori($kategori)
    {
        return $this->db->get_where('barang', ['kategori' => $kategori])->result();
    }

    public function detail_barang($id)
{
    $result = $this->db->where('id_brg', $id)->get('tb_barang');
    return $result->row();
}

}
