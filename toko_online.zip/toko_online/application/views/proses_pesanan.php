<div class="container-fluid">
    <div class="alert alert-success text-center">
        <p class="align-middle">Berhasil diproses!!!</p>
        <a href="<?php echo base_url('dashboard') ?>" class="btn btn-sm btn-primary mt-3">Kembali ke Dashboard</a>
    </div>
</div>
