<div class="container-fluid">
    <h4>Detail Pesanan 
        <div class="btn btn-sm btn-success">
            No. Invoice: <?php echo $invoice->id ?>
        </div>
    </h4>

    <table class="table table-bordered table-hover table-striped">
        <tr>
            <th>ID BARANG</th>
            <th>NAMA PRODUK</th>
            <th>JUMLAH PESANAN</th>
            <th>HARGA SATUAN</th>
            <th>SUB-TOTAL</th>
        </tr>

        <?php 
        $total = 0;
        if (isset($pesanan) && is_array($pesanan)) : 
            foreach ($pesanan as $psn) : 
                $subtotal = $psn->jumlah * $psn->harga;
                $total += $subtotal;
        ?>
        <tr>
            <td><?= $psn->id_barang ?></td>
            <td><?= $psn->nama_barang ?></td>
            <td><?= $psn->jumlah ?></td>
            <td>Rp. <?= number_format($psn->harga, 0, ',', '.') ?></td>
            <td>Rp. <?= number_format($subtotal, 0, ',', '.') ?></td>
        </tr>
        <?php endforeach; ?>

        <tr> 
            <td colspan="4" align="right"><strong>Grand Total</strong></td>
            <td align="right"><strong>Rp. <?= number_format($total, 0, ',', '.') ?></strong></td>
        </tr>

        <?php else : ?>
        <tr>
            <td colspan="5" class="text-center">Tidak ada data pesanan</td>
        </tr>
        <?php endif; ?>
    </table>

    <a href="<?= base_url('admin/invoice/index') ?>">
        <div class="btn btn-sm btn-primary">Kembali</div>
    </a>
</div>
