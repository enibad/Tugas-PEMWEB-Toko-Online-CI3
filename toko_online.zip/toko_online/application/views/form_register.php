<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-5">
            <h3 class="text-center mb-4">Register</h3>

            <?= validation_errors('<div class="alert alert-danger">', '</div>'); ?>
            
            <form method="post" action="<?= base_url('auth/register') ?>">
                <div class="form-group mb-3">
                    <label>Username</label>
                    <input type="text" name="username" class="form-control" value="<?= set_value('username') ?>">
                </div>
                <div class="form-group mb-3">
                    <label>Password</label>
                    <input type="password" name="password1" class="form-control">
                </div>
                <div class="form-group mb-3">
                    <label>Konfirmasi Password</label>
                    <input type="password" name="password2" class="form-control">
                </div>
                <button type="submit" class="btn btn-primary w-100">Daftar</button>
            </form>
            <div class="text-center mt-3">
                <a href="<?= base_url('auth/login') ?>">Sudah punya akun? Login</a>
            </div>
        </div>
    </div>
</div>
