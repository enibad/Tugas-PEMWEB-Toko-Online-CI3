<div class="container-fluid mt-3">
    <h4>Detail Barang</h4>

    <div class="card mb-3" style="max-width: 900px;">
        <div class="row g-0">
            <div class="col-md-4">
                <img src="<?= base_url('uploads/' . $barang->gambar) ?>" class="img-fluid rounded-start" alt="<?= $barang->nama_brg ?>">
            </div>
            <div class="col-md-8">
                <div class="card-body">
                    <table class="table table-striped">
                        <tr>
                            <td><strong>Nama Produk</strong></td>
                            <td><?= $barang->nama_brg ?></td>
                        </tr>
                        <tr>
                            <td><strong>Keterangan</strong></td>
                            <td><?= $barang->keterangan ?></td>
                        </tr>
                        <tr>
                            <td><strong>Kategori</strong></td>
                            <td><?= $barang->kategori ?></td>
                        </tr>
                        <tr>
                            <td><strong>Stok</strong></td>
                            <td><?= $barang->stok ?></td>
                        </tr>
                        <tr>
                            <td><strong>Harga</strong></td>
                            <td>Rp. <?= number_format($barang->harga, 0, ',', '.') ?></td>
                        </tr>
                    </table>

                    <a href="<?= base_url('dashboard') ?>" class="btn btn-sm btn-secondary">Kembali</a>
                    <a href="<?= base_url('dashboard/tambah_ke_keranjang/' . $barang->id_barang) ?>" class="btn btn-sm btn-primary">Tambah ke Keranjang</a>
                </div>
            </div>
        </div>
    </div>
</div>
