<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link href="<?= base_url('assets/vendor/bootstrap/css/bootstrap.min.css') ?>" rel="stylesheet">
    <style>
        body {
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: #f8f9fc;
        }
        .login-box {
            width: 100%;
            max-width: 400px;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            background: white;
        }
    </style>
</head>
<body>

    <div class="login-box">
        <h3 class="text-center mb-4">Login</h3>
        <?php echo $this->session->flashdata('pesan') ?>
        <form method="post" action="<?= base_url('auth/login') ?>">
            <div class="form-group">
                <label>Username</label>
                <input type="text" name="username" class="form-control" placeholder="Masukkan username...">
            </div>
            <div class="form-group mt-3">
                <label>Password</label>
                <input type="password" name="password" class="form-control" placeholder="Masukkan password...">
            </div>
            <button type="submit" class="btn btn-primary btn-block mt-4">Login</button>
            <div class="text-center mt-3">
                <a href="<?= base_url('auth/register') ?>" class="small">Belum punya akun? Daftar</a>
            </div>
        </form>
    </div>

    


    <!-- Bootstrap JS -->
    <script src="<?= base_url('assets/vendor/bootstrap/js/bootstrap.bundle.min.js') ?>"></script>
</body>
</html>
